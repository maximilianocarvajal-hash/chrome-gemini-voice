'use strict';

/**
 * Gemini Voice Chat — Chrome extension (side panel)
 * Author: Maximiliano Carvajal Orellana
 * Mathematical Engineering — Universidad de Santiago de Chile (USACH)
 */

// ============================================
// I18N TRANSLATIONS
// ============================================
const I18N = {
  es: {
    disconnected: 'Desconectado', connecting: 'Conectando...', rotating: 'Rotando API key...',
    connected: 'Conectado', errorConnection: 'Error de conexion',
    speak: 'Hablar', stop: 'Detener', send: 'Enviar', analyze: 'Analizar', fix: 'Solucionar',
    save: 'Guardar', saveSettings: 'Guardar ajustes', saveKeys: 'Guardar API keys', saveLang: 'Guardar idioma',
    settingsSaved: 'Ajustes guardados. Si estabas conectado, reconecta para aplicarlos.',
    keysSaved: 'API keys guardadas', langSaved: 'Idioma guardado',
    missingApiKey: 'Falta configurar al menos una API key en la pestana Ajustes.',
    connectedMsg: 'Conectado a Gemini Live.', micError: 'No se pudo acceder al microfono. Abriendo el diagnostico...',
    convEnded: 'Conversacion finalizada.', noConvToDownload: 'Todavia no hay conversacion para descargar.',
    restoredConv: 'Se restauro la conversacion guardada anteriormente.',
    connectFirst: 'Conecta primero (boton "Hablar") para poder enviar mensajes o adjuntos.',
    folderAttached: 'Carpeta adjuntada', filesAttached: 'archivos adjuntados',
    folderNotSupported: 'No se admite adjuntar carpetas completas, solo archivos individuales.',
    fileTooBig: 'es demasiado grande (max. 15MB) y no se adjunto.',
    fileReadError: 'No se pudo leer', keyRotated: 'Se roto a la API key', of: 'de',
    modelDetected: 'Modelo detectado', rememberSave: 'Recuerda pulsar "Guardar ajustes".',
    modelStillAvailable: 'El modelo configurado sigue disponible, no se cambio nada',
    noModelFound: 'No se encontro ningun modelo de voz en tiempo real disponible con esta API key.',
    modelQueryError: 'No se pudo consultar la lista de modelos', saveKeyFirst: 'Guarda al menos una API key primero.',
    searchingModels: 'Buscando modelos disponibles...', noIssues: 'No se detectaron problemas de microfono.',
    analysisComplete: 'Analisis completado', problemsDetected: 'problema(s) detectado(s)',
    problemsFixed: 'Problemas corregidos.', problemsNotFixed: 'Problemas no corregidos. Revisa el detalle debajo o la pestana Registro.',
    analysisRequested: 'Analisis solicitado.', fixRequested: 'Solucion solicitada.', applyingFix: 'Aplicando solucion...',
    defaultMic: 'predeterminado del sistema', micChanged: 'Se cambio el microfono seleccionado a',
    defaultMicReset: 'Se restablecio el microfono predeterminado del sistema.',
    openedSettings: 'Se abrio un panel de configuracion del navegador', checkManually: 'para revisar manualmente.',
    noLogYet: 'Todavia no hay registro. El registro se completa al analizar o al intentar resolver un problema.',
    introText: 'Presiona "Analizar" para revisar el microfono, los permisos y el nivel de senal de audio.',
    analyzingMic: 'Analizando microfono, permisos y nivel de senal de audio...',
    copied: 'Copiado al portapapeles', paypalCopied: 'PayPal copiado al portapapeles',
    dragHint: 'Suelta archivos o carpetas aqui para adjuntarlos',
    textPlaceholder: 'Escribe un mensaje (alternativa sin voz)...',
    tabChat: 'Chat', tabDiag: 'Microfono', tabSettings: 'Ajustes',
    subtabDiag: 'Diagnostico', subtabLogs: 'Registro',
    voiceLabel: 'Voz', mainLang: 'Idioma principal', secondLang: 'Segundo idioma',
    bilingualMode: 'Modo bilingue', vadAuto: 'VAD automatico',
    vadHint: 'Detecta cuando dejaste de hablar para que el asistente sepa que es su turno de responder, sin que tengas que pulsar ningun boton.',
    silenceLabel: 'Silencio para cortar el turno',
    silenceHint: 'Cuanto silencio tiene que pasar (en milisegundos) despues de que hablaste para que el asistente entienda que terminaste. Subelo si el asistente te interrumpe mientras piensas una frase; reducelo si tarda mucho en responder.',
    tempLabel: 'Temperatura de respuesta', modelLabel: 'Modelo', modelNameLabel: 'Nombre del modelo Live',
    convLabel: 'Conversacion', saveConvLabel: 'Guardar conversacion automaticamente en este navegador',
    saveConvHint: 'Si lo activas, los mensajes quedan guardados en este dispositivo (no en un servidor) y se recuperan la proxima vez que abras la extension. Puedes borrarlos o descargarlos como archivo de texto desde el chat con el boton ⬇️.',
    apiKeysTitle: 'API keys de Gemini', apiKeyHint1: 'No tienes una API key? Consigue una gratis en',
    apiKeyHint2: 'Con tu cuenta de Google, inicias sesion ahi y el sitio te genera la key con un boton — no hace falta configurar nada mas.',
    apiKeyHint3: 'Pega cada API key en', apiKeyHint4: 'su propia linea', apiKeyHint5: '(pulsando Enter entre una y otra). No se separan con comas ni con espacios. Ejemplo, con dos keys:',
    apiKeyHint6: 'Si pones mas de una, la extension rota automaticamente a la siguiente cuando una se queda sin cuota.',
    interfaceLang: 'Idioma de la interfaz', interfaceLangHint: 'Elige el idioma en el que se muestran los menus, botones y mensajes del sistema.',
    donationTitle: 'Aporte voluntario', creatorName: 'Maximiliano Carvajal Orellana',
    creatorDegree: 'Ingenieria Matematica — Universidad de Santiago de Chile (USACH)',
    paypalLabel: 'Internacional — PayPal', paypalValue: 'gangliosacroz@gmail.com',
    paypalNote: 'Pulsa para copiar al portapapeles',
    voiceLangTitle: 'Voz e idioma', vadTitle: 'Voz — deteccion de actividad (VAD)',
    detectModelBtn: 'Detectar modelo automaticamente',
    infoDualLang: 'Normalmente el asistente espera que le hables siempre en el mismo idioma ("Idioma principal"). Con el modo bilingue activado, puedes hablarle en ese idioma <strong>o</strong> en el "Segundo idioma" que elijas abajo, incluso cambiando de uno a otro en la misma conversacion, y el asistente detecta cual usaste y te responde en ese mismo idioma. Util si estas aprendiendo un idioma o hablas con gente que usa dos idiomas distintos.',
    infoTemp: 'Controla que tan "creativas" o "predecibles" son las respuestas. Con un valor bajo (cerca de 0), el asistente responde siempre de forma mas directa y parecida ante la misma pregunta. Con un valor alto (cerca de 2), varia mas sus respuestas y puede sonar mas espontaneo, pero tambien mas impredecible. Si no sabes que elegir, dejalo en 0.9 (el valor por defecto): es un buen equilibrio para una conversacion natural.',
    infoModel: 'Es el "motor" de inteligencia artificial que atiende la conversacion de voz. Google a veces retira modelos viejos o los reemplaza por versiones nuevas; si el nombre que esta guardado deja de existir, la conexion va a fallar. Usa el boton "Detectar automaticamente" para que la extension busque el modelo de voz mas adecuado disponible en este momento.',
    micHowToTitle: 'Como activar el microfono?',
    micStep1: 'Haz <strong>clic derecho</strong> sobre el icono de la extension en la barra.',
    micStep2: 'Selecciona <strong>"Ver permisos web de la extension"</strong>.',
    micStep3: 'Busca <strong>Microfono</strong> y cambialo a <strong>"Permitir"</strong>.',
    micStep4: 'Abre la extension y pulsa <strong>"Hablar"</strong>.',
    attachTitle: 'Adjuntar archivo(s)', downloadTitle: 'Descargar conversacion',
    volumeTitle: 'Nivel de volumen captado por el microfono',
    apiKeysPlaceholder: 'AIzaSy... (una por linea)',
    apiKeyExample: 'AIzaSyABC123...primeraKey\nAIzaSyXYZ789...segundaKey',
    'apiKeyHint3-html': 'Pega cada API key en <strong>su propia linea</strong> (pulsando Enter entre una y otra). No se separan con comas ni con espacios. Ejemplo, con dos keys:',
  },
  en: {
    disconnected: 'Disconnected', connecting: 'Connecting...', rotating: 'Rotating API key...',
    connected: 'Connected', errorConnection: 'Connection error',
    speak: 'Speak', stop: 'Stop', send: 'Send', analyze: 'Analyze', fix: 'Fix',
    save: 'Save', saveSettings: 'Save settings', saveKeys: 'Save API keys', saveLang: 'Save language',
    settingsSaved: 'Settings saved. If you were connected, reconnect to apply them.',
    keysSaved: 'API keys saved', langSaved: 'Language saved',
    missingApiKey: 'Please configure at least one API key in the Settings tab.',
    connectedMsg: 'Connected to Gemini Live.', micError: 'Could not access microphone. Opening diagnostics...',
    convEnded: 'Conversation ended.', noConvToDownload: 'No conversation to download yet.',
    restoredConv: 'Previous conversation restored.',
    connectFirst: 'Connect first ("Speak" button) to send messages or attachments.',
    folderAttached: 'Folder attached', filesAttached: 'files attached',
    folderNotSupported: 'Attaching whole folders is not supported, only individual files.',
    fileTooBig: 'is too large (max 15MB) and was not attached.',
    fileReadError: 'Could not read', keyRotated: 'Rotated to API key', of: 'of',
    modelDetected: 'Model detected', rememberSave: 'Remember to click "Save settings".',
    modelStillAvailable: 'The configured model is still available, nothing was changed',
    noModelFound: 'No real-time voice model found with this API key.',
    modelQueryError: 'Could not query model list', saveKeyFirst: 'Save at least one API key first.',
    searchingModels: 'Searching available models...', noIssues: 'No microphone issues detected.',
    analysisComplete: 'Analysis completed', problemsDetected: 'problem(s) detected',
    problemsFixed: 'Issues fixed.', problemsNotFixed: 'Issues not fixed. Check details below or the Log tab.',
    analysisRequested: 'Analysis requested.', fixRequested: 'Fix requested.', applyingFix: 'Applying fix...',
    defaultMic: 'system default', micChanged: 'Microphone changed to',
    defaultMicReset: 'System default microphone restored.',
    openedSettings: 'Browser settings panel opened', checkManually: 'to check manually.',
    noLogYet: 'No log yet. The log is populated when analyzing or attempting to fix a problem.',
    introText: 'Press "Analyze" to check the microphone, permissions, and audio signal level.',
    analyzingMic: 'Analyzing microphone, permissions, and audio signal level...',
    copied: 'Copied to clipboard', paypalCopied: 'PayPal copied to clipboard',
    dragHint: 'Drop files or folders here to attach them',
    textPlaceholder: 'Type a message (voice alternative)...',
    tabChat: 'Chat', tabDiag: 'Microphone', tabSettings: 'Settings',
    subtabDiag: 'Diagnostics', subtabLogs: 'Log',
    voiceLabel: 'Voice', mainLang: 'Primary language', secondLang: 'Second language',
    bilingualMode: 'Bilingual mode', vadAuto: 'Auto VAD',
    vadHint: 'Detects when you stop speaking so the assistant knows it is their turn to respond, without you having to press any button.',
    silenceLabel: 'Silence to end turn',
    silenceHint: 'How much silence (in milliseconds) must pass after you speak for the assistant to understand you finished. Increase it if the assistant interrupts you while thinking; decrease it if it takes too long to respond.',
    tempLabel: 'Response temperature', modelLabel: 'Model', modelNameLabel: 'Live model name',
    convLabel: 'Conversation', saveConvLabel: 'Automatically save conversation in this browser',
    saveConvHint: 'If enabled, messages are saved on this device (not on a server) and recovered the next time you open the extension. You can delete or download them as a text file from the chat with the ⬇️ button.',
    apiKeysTitle: 'Gemini API keys', apiKeyHint1: "Don't have an API key? Get one for free at",
    apiKeyHint2: 'With your Google account, sign in there and the site generates the key with one button — no further setup needed.',
    apiKeyHint3: 'Paste each API key on', apiKeyHint4: 'its own line', apiKeyHint5: '(pressing Enter between them). Do not separate with commas or spaces. Example with two keys:',
    apiKeyHint6: 'If you add more than one, the extension automatically rotates to the next when one runs out of quota.',
    interfaceLang: 'Interface language', interfaceLangHint: 'Choose the language for menus, buttons, and system messages.',
    donationTitle: 'Voluntary contribution', creatorName: 'Maximiliano Carvajal Orellana',
    creatorDegree: 'Mathematical Engineering — University of Santiago, Chile (USACH)',
    paypalLabel: 'International — PayPal', paypalValue: 'gangliosacroz@gmail.com',
    paypalNote: 'Click to copy to clipboard',
    voiceLangTitle: 'Voice and language', vadTitle: 'Voice — activity detection (VAD)',
    detectModelBtn: 'Auto-detect model',
    infoDualLang: 'Normally the assistant expects you to always speak in the same language ("Primary language"). With bilingual mode on, you can speak in that language <strong>or</strong> in the "Second language" you choose below, even switching between them in the same conversation, and the assistant detects which one you used and replies in that same language. Useful if you are learning a language or talk to people who use two different languages.',
    infoTemp: 'Controls how "creative" or "predictable" the responses are. With a low value (near 0), the assistant always responds in a more direct, similar way to the same question. With a high value (near 2), it varies its responses more and can sound more spontaneous, but also less predictable. If you are not sure what to choose, leave it at 0.9 (the default): it is a good balance for a natural conversation.',
    infoModel: 'This is the AI "engine" that handles the voice conversation. Google sometimes retires old models or replaces them with newer versions; if the saved name stops existing, the connection will fail. Use the "Auto-detect" button so the extension looks up the most suitable voice model available right now.',
    micHowToTitle: 'How do I enable the microphone?',
    micStep1: '<strong>Right-click</strong> the extension icon in the toolbar.',
    micStep2: 'Select <strong>"View web permissions"</strong>.',
    micStep3: 'Find <strong>Microphone</strong> and set it to <strong>"Allow"</strong>.',
    micStep4: 'Open the extension and click <strong>"Speak"</strong>.',
    attachTitle: 'Attach file(s)', downloadTitle: 'Download conversation',
    volumeTitle: 'Microphone input volume level',
    apiKeysPlaceholder: 'AIzaSy... (one per line)',
    apiKeyExample: 'AIzaSyABC123...firstKey\nAIzaSyXYZ789...secondKey',
    'apiKeyHint3-html': 'Paste each API key on <strong>its own line</strong> (press Enter between each one). Do not separate them with commas or spaces. Example, with two keys:',
  }
};

let currentLang = 'es';
function t(key) {
  return (I18N[currentLang] && I18N[currentLang][key]) || (I18N['es'][key]) || key;
}

const DEFAULT_SETTINGS = {
  geminiApiKeys: [], activeApiKeyIndex: 0, voiceName: 'Kore', languageHint: 'es-419',
  showTranscriptions: true, inputSampleRate: 16000, outputSampleRate: 24000, bufferSize: 2048,
  vadEnabled: true, vadPrefixPaddingMs: 20, vadSilenceDurationMs: 700, debugMode: false,
  dualLanguageMode: false, language2: 'en-US', responseTemperature: 0.9,
  geminiModel: 'gemini-3.1-flash-live-preview', preferredMicDeviceId: '', preferredMicLabel: '',
  saveConversation: false, uiLanguage: 'es'
};

const LIVE_MODEL_DEFAULT = 'gemini-3.1-flash-live-preview';
const WS_BASE_URL = 'wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent';

function floatTo16BitPCM(floatArray) {
    const intArray = new Int16Array(floatArray.length);
    for (let i = 0; i < floatArray.length; i++) {
        let s = Math.max(-1, Math.min(1, floatArray[i]));
        intArray[i] = s < 0 ? s * 0x8000 : s * 0x7FFF;
    }
    return intArray;
}

function pcm16ToFloat32(intArray) {
    const floatArray = new Float32Array(intArray.length);
    for (let i = 0; i < intArray.length; i++) {
        floatArray[i] = intArray[i] / 0x8000;
    }
    return floatArray;
}

function resampleAudio(floatArray, sourceRate, targetRate) {
    if (sourceRate === targetRate) return floatArray;
    const ratio = targetRate / sourceRate;
    const newLength = Math.floor(floatArray.length * ratio);
    const result = new Float32Array(newLength);
    for (let i = 0; i < newLength; i++) {
        const pos = i / ratio;
        const idx = Math.floor(pos);
        const frac = pos - idx;
        const s0 = floatArray[idx] || 0;
        const s1 = floatArray[idx + 1] || s0;
        result[i] = s0 + frac * (s1 - s0);
    }
    return result;
}

function arrayBufferToBase64(buffer) {
    const bytes = new Uint8Array(buffer);
    let binary = '';
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
        binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
}

function base64ToInt16Array(base64) {
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
        bytes[i] = binary.charCodeAt(i);
    }
    return new Int16Array(bytes.buffer);
}

function calculateRMS(floatArray) {
    let sum = 0;
    for (let i = 0; i < floatArray.length; i++) {
        sum += floatArray[i] * floatArray[i];
    }
    return Math.sqrt(sum / floatArray.length);
}

// ============================================
// AUDIO MANAGER v1.4.0 — PATCHED
// ============================================
// Fixes:
// - nextPlaybackTime resets on prolonged silence (>3s) to prevent growing latency
// - _sgSilenceThreshold lowered to 0.003 for better detection
// - Audio always sent (even silence) to keep stream alive
// - Improved MediaRecorder fallback

class AudioManager {
    constructor(settings) {
        this.settings = settings || DEFAULT_SETTINGS;
        this.audioContext = null;
        this.mediaStream = null;
        this.sourceNode = null;
        this.processorNode = null;
        this.onAudioChunk = null;
        this.onVolumeUpdate = null;
        this.isCapturing = false;
        this.nextPlaybackTime = 0;
        this._activeSources = [];
        this._recentAudioHashes = new Set();
        this._recentAudioFingerprints = new Set();
        this._maxAudioHashes = 1000;          // suficiente para minutos de audio
        this._lastChunkStartTime = 0;
        this._lastChunkHash = '';
        this._lastChunkFingerprint = '';
        this._lastAudioChunkIndex = -1;       // índice del último chunk reproducido
        this.actualSampleRate = 0;
        this.chunksSent = 0;
        this.chunksPlayed = 0;
        this.resampleBuffer = [];
        this.captureInterval = null;
        this._lastSilenceTime = 0;
        this._consecutiveSilenceChunks = 0;
    }

    async init() {
        if (!this.audioContext) {
            this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
        }
        if (this.audioContext.state === 'suspended') {
            try {
                await this.audioContext.resume();
                let attempts = 0;
                while (this.audioContext.state !== 'running' && attempts < 50) {
                    await new Promise(r => setTimeout(r, 50));
                    attempts++;
                }
            } catch (e) {
                console.error('[GVC] Error resuming AudioContext:', e);
            }
        }
        console.log('[GVC] AudioContext state:', this.audioContext.state, 'sampleRate:', this.audioContext.sampleRate);
        return this.audioContext;
    }

    async startCapture(onChunk, onVolume) {
        this.onAudioChunk = onChunk;
        this.onVolumeUpdate = onVolume;
        this.resampleBuffer = [];
        this.chunksSent = 0;
        this._lastSilenceTime = 0;
        this._consecutiveSilenceChunks = 0;

        try {
            await this.init();
            const requestedRate = this.settings.inputSampleRate || 16000;

            const audioConstraints = {
                channelCount: 1,
                sampleRate: { ideal: requestedRate },
                echoCancellation: { ideal: true },
                noiseSuppression: { ideal: true },
                autoGainControl: { ideal: true },
                googNoiseSuppression: true,
                googHighpassFilter: true,
                googAutoGainControl: true,
                latency: { ideal: 0.01 }
            };
            if (this.settings.preferredMicDeviceId) {
                audioConstraints.deviceId = { exact: this.settings.preferredMicDeviceId };
            }

            this.mediaStream = await navigator.mediaDevices.getUserMedia({ audio: audioConstraints });

            const audioTrack = this.mediaStream.getAudioTracks()[0];
            const trackSettings = audioTrack.getSettings();
            this.actualSampleRate = trackSettings.sampleRate || this.audioContext.sampleRate || 48000;

            console.log('[GVC] Mic sampleRate requested:', requestedRate, '| actual:', this.actualSampleRate, '| trackSettings:', JSON.stringify(trackSettings));

            this.sourceNode = this.audioContext.createMediaStreamSource(this.mediaStream);
            const bufferSize = this.settings.bufferSize || 2048;
            // createScriptProcessor esta deprecado pero aun funciona en Chrome.
            // AudioWorklet requiere un .js separado (no viable en extension MV3).
            // El warning amarillo en consola es normal y no afecta el audio.
            if (!this.audioContext || !this.audioContext.createScriptProcessor) {
                throw new Error('AudioContext not ready or ScriptProcessor unavailable');
            }
            this.processorNode = this.audioContext.createScriptProcessor(bufferSize, 1, 1);

            this._sgIsSpeaking = false;
            this._sgSilenceStart = null;
            this._sgSilenceThreshold = 0.003; // LOWERED from 0.008 for better detection
            this._sgSilenceHoldMs = (this.settings.vadSilenceDurationMs || 700); // REMOVED extra +300ms

            this.processorNode.onaudioprocess = (e) => {
                if (!this.isCapturing) return;
                const inputData = e.inputBuffer.getChannelData(0);
                const targetRate = this.settings.inputSampleRate || 16000;
                const rms = calculateRMS(inputData);
                if (this.onVolumeUpdate) this.onVolumeUpdate(rms);

                const now = Date.now();
                const isSilent = rms < this._sgSilenceThreshold;

                if (!isSilent) {
                    this._sgIsSpeaking = true;
                    this._sgSilenceStart = null;
                    this._consecutiveSilenceChunks = 0;
                } else if (this._sgIsSpeaking) {
                    if (this._sgSilenceStart === null) {
                        this._sgSilenceStart = now;
                    }
                    if (now - this._sgSilenceStart >= this._sgSilenceHoldMs) {
                        this._sgIsSpeaking = false;
                        this._sgSilenceStart = null;
                    }
                }

                // Reset nextPlaybackTime on prolonged silence (>3s) — PREVENTS GROWING LATENCY
                if (isSilent) {
                    this._consecutiveSilenceChunks++;
                    if (this._consecutiveSilenceChunks > 140) { // ~3s at 16kHz/2048
                        if (this.audioContext && this.nextPlaybackTime > this.audioContext.currentTime + 0.5) {
                            this.nextPlaybackTime = this.audioContext.currentTime;
                            console.log('[GVC] Reset nextPlaybackTime due to prolonged silence');
                        }
                        this._consecutiveSilenceChunks = 0;
                    }
                }

                let audioToSend = inputData;
                if (this.actualSampleRate !== targetRate) {
                    audioToSend = resampleAudio(inputData, this.actualSampleRate, targetRate);
                }

                const pcmData = floatTo16BitPCM(audioToSend);
                const base64Data = arrayBufferToBase64(pcmData.buffer);

                // Always send audio, even silence, to keep stream alive
                // Server-side VAD (Gemini) will handle silence detection
                if (this.onAudioChunk) {
                    this.onAudioChunk(base64Data, this._sgIsSpeaking);
                    this.chunksSent++;
                }
            };

            this.sourceNode.connect(this.processorNode);
            const zeroGain = this.audioContext.createGain();
            zeroGain.gain.value = 0;
            this.processorNode.connect(zeroGain);
            zeroGain.connect(this.audioContext.destination);

            this.isCapturing = true;

            setTimeout(() => {
                if (this.isCapturing && this.chunksSent === 0) {
                    console.warn('[GVC] ScriptProcessorNode generated no chunks. Trying fallback...');
                    this._tryMediaRecorderFallback();
                }
            }, 3000);

            return true;

        } catch (err) {
            console.error('[GVC] Error starting capture:', err);
            this.lastCaptureError = err;

            if (this.settings.preferredMicDeviceId && (err.name === 'OverconstrainedError' || err.name === 'NotFoundError')) {
                console.warn('[GVC] Preferred mic unavailable, retrying with system default...');
                this.settings.preferredMicDeviceId = '';
                return this.startCapture(onChunk, onVolume);
            }

            return false;
        }
    }

    async listInputDevices() {
        if (!navigator.mediaDevices || !navigator.mediaDevices.enumerateDevices) return [];
        const devices = await navigator.mediaDevices.enumerateDevices();
        return devices.filter(d => d.kind === 'audioinput');
    }

    async _tryMediaRecorderFallback() {
        if (!this.mediaStream || this.chunksSent > 0) return;
        console.log('[GVC] Activating MediaRecorder fallback...');

        try {
            const mediaRecorder = new MediaRecorder(this.mediaStream, {
                mimeType: 'audio/webm;codecs=opus',
                audioBitsPerSecond: 16000
            });

            const audioChunks = [];
            mediaRecorder.ondataavailable = (event) => {
                if (event.data.size > 0) audioChunks.push(event.data);
            };

            mediaRecorder.onstop = async () => {
                const blob = new Blob(audioChunks, { type: 'audio/webm' });
                const arrayBuffer = await blob.arrayBuffer();
                const audioBuffer = await this.audioContext.decodeAudioData(arrayBuffer);
                const channelData = audioBuffer.getChannelData(0);

                const targetRate = this.settings.inputSampleRate || 16000;
                let audioToSend = channelData;
                if (audioBuffer.sampleRate !== targetRate) {
                    audioToSend = resampleAudio(channelData, audioBuffer.sampleRate, targetRate);
                }

                const pcmData = floatTo16BitPCM(audioToSend);
                const base64Data = arrayBufferToBase64(pcmData.buffer);

                if (this.onAudioChunk) {
                    this.onAudioChunk(base64Data);
                    this.chunksSent++;
                }
            };

            mediaRecorder.start(100);
            this._mediaRecorder = mediaRecorder;

        } catch (err) {
            console.error('[GVC] MediaRecorder fallback failed:', err);
        }
    }

    stopCapture() {
        this.isCapturing = false;
        if (this._mediaRecorder && this._mediaRecorder.state !== 'inactive') {
            try { this._mediaRecorder.stop(); } catch(e) {}
            this._mediaRecorder = null;
        }
        if (this.processorNode) {
            try { this.processorNode.disconnect(); } catch(e) {}
            this.processorNode.onaudioprocess = null;
            this.processorNode = null;
        }
        if (this.sourceNode) {
            try { this.sourceNode.disconnect(); } catch(e) {}
            this.sourceNode = null;
        }
        if (this.mediaStream) {
            this.mediaStream.getTracks().forEach(track => track.stop());
            this.mediaStream = null;
        }
        this.nextPlaybackTime = 0;
        this._consecutiveSilenceChunks = 0;
    }

    playPCM(base64Data, sourceSampleRate, chunkIndex) {
        if (!this.audioContext) return null;

        // Validación de secuencia: si chunkIndex <= último reproducido, es duplicado
        // o llegó fuera de orden (retransmisión). Solo aceptamos chunks nuevos.
        if (chunkIndex !== undefined && chunkIndex <= this._lastAudioChunkIndex) {
            console.log('[GVC] Duplicate audio chunk ignored (index ' + chunkIndex + ' <= last ' + this._lastAudioChunkIndex + ')');
            return null;
        }
        if (chunkIndex !== undefined) {
            this._lastAudioChunkIndex = chunkIndex;
        }

        const hash = this._hashAudio(base64Data);
        const fingerprint = this._audioFingerprint(base64Data);
        const now = this.audioContext.currentTime;

        // Deduplicacion por hash base64: chunk exacto duplicado
        if (this._recentAudioHashes.has(hash)) {
            console.log('[GVC] Duplicate audio chunk ignored (base64 hash match)');
            return null;
        }

        // Deduplicacion por firma de audio: retransmision con base64 diferente
        if (this._recentAudioFingerprints && this._recentAudioFingerprints.has(fingerprint)) {
            console.log('[GVC] Duplicate audio chunk ignored (PCM fingerprint match)');
            return null;
        }

        // Cooldown: si un chunk llega < 80ms despues del inicio del anterior
        if ((hash === this._lastChunkHash || fingerprint === this._lastChunkFingerprint) &&
            (now - this._lastChunkStartTime) < 0.08) {
            console.log('[GVC] Duplicate audio chunk ignored (rapid cooldown)');
            return null;
        }

        this._recentAudioHashes.add(hash);
        if (this._recentAudioHashes.size > this._maxAudioHashes) {
            const first = this._recentAudioHashes.values().next().value;
            this._recentAudioHashes.delete(first);
        }
        if (!this._recentAudioFingerprints) this._recentAudioFingerprints = new Set();
        this._recentAudioFingerprints.add(fingerprint);
        if (this._recentAudioFingerprints.size > this._maxAudioHashes) {
            const first = this._recentAudioFingerprints.values().next().value;
            this._recentAudioFingerprints.delete(first);
        }

        if (this.audioContext.state === 'suspended') this.audioContext.resume();

        sourceSampleRate = sourceSampleRate || this.settings.outputSampleRate || 24000;

        try {
            const pcmData = base64ToInt16Array(base64Data);
            let floatData = pcm16ToFloat32(pcmData);

            const targetRate = this.audioContext.sampleRate || 48000;
            if (sourceSampleRate !== targetRate) {
                floatData = resampleAudio(floatData, sourceSampleRate, targetRate);
            }

            const buffer = this.audioContext.createBuffer(1, floatData.length, targetRate);
            buffer.getChannelData(0).set(floatData);

            const source = this.audioContext.createBufferSource();
            source.buffer = buffer;
            source.connect(this.audioContext.destination);

            // MODO SECUENCIAL: si hay un source activo, esperar a que termine.
            // Esto evita que dos chunks se solapen y produzcan "doble voz".
            const currentTime = this.audioContext.currentTime;
            const scheduledTime = Math.max(currentTime, this.nextPlaybackTime);

            // Si hay audio activo sonando ahora, nextPlaybackTime ya esta adelante.
            // Si no hay nada, scheduledTime = currentTime.
            source.start(scheduledTime);
            this.nextPlaybackTime = scheduledTime + buffer.duration;

            // Rastrear para poder detener en disconnect()
            this._activeSources.push(source);
            source.onended = () => {
                const idx = this._activeSources.indexOf(source);
                if (idx !== -1) this._activeSources.splice(idx, 1);
            };

            this._lastChunkStartTime = scheduledTime;
            this._lastChunkHash = hash;
            this._lastChunkFingerprint = fingerprint;
            this.chunksPlayed++;

            return source;
        } catch (err) {
            console.error('[GVC] Error playing audio:', err);
            return null;
        }
    }

    _hashAudio(base64) {
        // Hash completo djb2 para evitar falsos negativos en deduplicacion
        let h = 5381;
        for (let i = 0; i < base64.length; i++) {
            h = ((h << 5) + h) + base64.charCodeAt(i);
            h |= 0;
        }
        return h + ':' + base64.length;
    }

    _audioFingerprint(base64) {
        // Firma del contenido de audio decodificado (robusta contra retransmisiones
        // con base64 diferente pero mismo audio). Samplea 50 puntos del PCM.
        try {
            const binary = atob(base64);
            const bytes = new Uint8Array(binary.length);
            for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
            const intArray = new Int16Array(bytes.buffer);
            let sum = 0;
            const step = Math.max(1, Math.floor(intArray.length / 50));
            for (let i = 0; i < intArray.length; i += step) {
                sum += Math.abs(intArray[i]);
            }
            return sum + ':' + intArray.length;
        } catch (e) {
            return '0:0';
        }
    }

    resetPlaybackSchedule() {
        // Solo usar en caso de emergencia (ej: desconexion manual).
        // En flujo normal, nextPlaybackTime se maneja secuencialmente en playPCM.
        if (this.audioContext) {
            this.nextPlaybackTime = this.audioContext.currentTime;
        } else {
            this.nextPlaybackTime = 0;
        }
    }

    clearRecentHashes() {
        this._recentAudioHashes.clear();
        if (this._recentAudioFingerprints) this._recentAudioFingerprints.clear();
        this._lastChunkStartTime = 0;
        this._lastChunkHash = '';
        this._lastChunkFingerprint = '';
        this._lastAudioChunkIndex = -1;
    }

    stopPlayback() {
        if (!this.audioContext) return;
        // Detener TODOS los sources activos inmediatamente
        this._activeSources.forEach(source => {
            try { source.stop(0); } catch(e) {}
        });
        this._activeSources = [];
        // Resetear el tiempo de reproduccion al momento actual
        this.nextPlaybackTime = this.audioContext.currentTime;
        this._lastChunkStartTime = 0;
        this._lastChunkHash = '';
        this._lastChunkFingerprint = '';
        this._lastAudioChunkIndex = -1;  // resetear índice de secuencia
    }

    dispose() {
        this.stopCapture();
        if (this.audioContext) {
            try { this.audioContext.close(); } catch(e) {}
            this.audioContext = null;
        }
        this.nextPlaybackTime = 0;
    }
}

// ============================================
// GEMINI LIVE CLIENT v1.4.0 — PATCHED
// ============================================
// Fixes:
// - Key rotation now works: disconnect() is NOT called before reconnect
// - Auto-reconnect with exponential backoff on network errors
// - Proper cleanup of ws before reconnect to avoid state conflicts

class GeminiLiveClient {
    constructor() {
        this.ws = null;
        this.apiKeys = [];
        this.currentKeyIndex = 0;
        this.isConnected = false;
        this.isConnecting = false;
        this.sessionConfig = null;
        this.connectionTimeout = null;
        this._quotaExhaustedKeys = new Set();
        this._rotationInProgress = false;
        this._reconnectAttempts = 0;
        this._maxReconnectAttempts = 5;
        this._reconnectDelay = 1000;
        this._intentionalDisconnect = false;
        // FIX: session resumption support (see goAway handling below)
        this._lastResumptionHandle = null;
        this._goAwayReceived = false;
        this._goAwayReconnectScheduled = false;

        this.onConnect = null;
        this.onDisconnect = null;
        this.onError = null;
        this.onAudioOutput = null;
        this.onTranscription = null;
        this.onStatusChange = null;
        this.onMessage = null;
        this.onKeyRotated = null;
    }

    _isQuotaError(code, reason, errorMsg) {
        const msg = (reason + ' ' + (errorMsg || '')).toLowerCase();
        const quotaPatterns = [
            'quota', 'rate limit', 'exceeded', '429', 'resource exhausted',
            'too many requests', 'limit exceeded', 'billing', 'over quota',
            'quota exceeded', 'rate_limit_exceeded'
        ];
        // FIX: code 1011 ("internal error") used to be treated as quota
        // exhaustion outright. It's a generic server-side error code — for
        // example it's what a malformed/unsupported attachment can trigger —
        // and treating it as "key exhausted" made a single bad file attachment
        // permanently kill the conversation for anyone with a single API key
        // ("all keys exhausted" with nothing left to rotate to). Only classify
        // it as quota if the reason text actually says so.
        return quotaPatterns.some(p => msg.includes(p)) || code === 1008;
    }

    _isNetworkError(code, reason) {
        const msg = (reason || '').toLowerCase();
        return code === 1006 || msg.includes('abnormal') || msg.includes('network') || msg.includes('connection');
    }

    _rotateKey() {
        if (this.apiKeys.length <= 1) return false;
        this._quotaExhaustedKeys.add(this.currentKeyIndex);
        let startIndex = this.currentKeyIndex;
        let nextIndex = (this.currentKeyIndex + 1) % this.apiKeys.length;
        while (nextIndex !== startIndex) {
            if (!this._quotaExhaustedKeys.has(nextIndex)) {
                this.currentKeyIndex = nextIndex;
                if (this.onKeyRotated) this.onKeyRotated(this.currentKeyIndex, this.apiKeys.length);
                return true;
            }
            nextIndex = (nextIndex + 1) % this.apiKeys.length;
        }
        return false;
    }

    resetKeyPool() {
        this._quotaExhaustedKeys.clear();
        this.currentKeyIndex = 0;
        this._reconnectAttempts = 0;
    }

    getActiveKey() {
        if (!this.apiKeys.length) return '';
        return this.apiKeys[this.currentKeyIndex] || '';
    }

    connect(apiKeys, config, reason) {
        if (this.isConnected || this.isConnecting) {
            console.warn('[GVC] Already connected or connecting');
            return;
        }

        this._lastConnectReason = reason || 'fresh';
        this.apiKeys = Array.isArray(apiKeys) ? apiKeys : (apiKeys ? [apiKeys] : []);
        this.sessionConfig = config || {};
        this.isConnecting = true;
        this._rotationInProgress = false;
        this._intentionalDisconnect = false;

        if (this.onStatusChange) this.onStatusChange('connecting');

        const activeKey = this.getActiveKey();
        if (!activeKey) {
            this.isConnecting = false;
            if (this.onError) this.onError(new Error('No API keys configured'));
            if (this.onStatusChange) this.onStatusChange('error');
            return;
        }

        const wsUrl = WS_BASE_URL + '?key=' + encodeURIComponent(activeKey);

        try {
            // Clean up any previous ws instance
            if (this.ws) {
                try { this.ws.onopen = null; this.ws.onmessage = null; this.ws.onerror = null; this.ws.onclose = null; } catch(e) {}
                this.ws = null;
            }

            this.ws = new WebSocket(wsUrl);

            this.connectionTimeout = setTimeout(() => {
                if (this.isConnecting) {
                    console.error('[GVC] Connection timeout');
                    this._cleanupConnection();
                    if (this.onError) this.onError(new Error('Connection timeout to Gemini Live API'));
                    if (this.onStatusChange) this.onStatusChange('error');
                }
            }, 10000);

            this.ws.onopen = () => {
                console.log('[GVC] WebSocket connected');
                if (this.connectionTimeout) {
                    clearTimeout(this.connectionTimeout);
                    this.connectionTimeout = null;
                }
                this.isConnecting = false;
                this.isConnected = true;
                this._reconnectAttempts = 0;
                this._reconnectDelay = 1000;
                this._sendSetup();
                if (this.onStatusChange) this.onStatusChange('connected');
            };

            this.ws.onmessage = async (event) => {
                let data = event.data;
                if (data instanceof Blob) {
                    try { data = await data.text(); } catch (e) { return; }
                }
                this._handleMessage(data);
            };

            this.ws.onerror = (error) => {
                console.error('[GVC] WebSocket error:', error);
                // Do NOT disconnect here — let onclose handle it to preserve error info
            };

            this.ws.onclose = (event) => {
                console.log('[GVC] WebSocket closed:', event.code, event.reason);
                if (this.connectionTimeout) {
                    clearTimeout(this.connectionTimeout);
                    this.connectionTimeout = null;
                }
                const wasConnected = this.isConnected;
                this.isConnected = false;
                this.isConnecting = false;

                // FIX: if the server had already warned us with goAway, this close
                // is expected (session time limit). Reconnect immediately using the
                // stored resumption handle instead of falling through to the
                // quota/network heuristics below, which wouldn't necessarily match.
                if (this._goAwayReceived) {
                    this._goAwayReceived = false;
                    this._goAwayReconnectScheduled = false;
                    if (this.onStatusChange) this.onStatusChange('connecting');
                    setTimeout(() => this.connect(this.apiKeys, this.sessionConfig, 'goaway'), 300);
                    return;
                }

                // Quota error → rotate key and reconnect
                if (this._isQuotaError(event.code, event.reason, '')) {
                    if (this._rotateKey()) {
                        console.warn('[GVC] Key exhausted (close ' + event.code + '). Rotating to key #' + (this.currentKeyIndex + 1));
                        if (this.onStatusChange) this.onStatusChange('rotating');
                        setTimeout(() => this.connect(this.apiKeys, this.sessionConfig, 'key-rotation'), 800);
                        return;
                    }
                    if (this.onError) this.onError(new Error('All API keys exhausted'));
                    if (this.onStatusChange) this.onStatusChange('error');
                    if (this.onDisconnect) this.onDisconnect(event.code, 'All keys exhausted');
                    return;
                }

                // Network error → auto-reconnect with backoff
                if (wasConnected && !this._intentionalDisconnect && this._isNetworkError(event.code, event.reason)) {
                    if (this._reconnectAttempts < this._maxReconnectAttempts) {
                        this._reconnectAttempts++;
                        const delay = this._reconnectDelay * Math.pow(2, this._reconnectAttempts - 1);
                        console.log('[GVC] Network error. Reconnecting in ' + delay + 'ms (attempt ' + this._reconnectAttempts + '/' + this._maxReconnectAttempts + ')');
                        if (this.onStatusChange) this.onStatusChange('connecting');
                        setTimeout(() => this.connect(this.apiKeys, this.sessionConfig, 'network'), delay);
                        return;
                    }
                    console.error('[GVC] Max reconnection attempts reached');
                }

                // FIX: catch-all — any other unexpected close while we were
                // connected (not something the user asked for) used to just end
                // the conversation with no retry, e.g. if the server hiccupped
                // right after an attachment was sent. Treat it like a network
                // blip and retry with backoff instead of silently dying.
                if (wasConnected && !this._intentionalDisconnect) {
                    if (this._reconnectAttempts < this._maxReconnectAttempts) {
                        this._reconnectAttempts++;
                        const delay = this._reconnectDelay * Math.pow(2, this._reconnectAttempts - 1);
                        console.log('[GVC] Unexpected close (code ' + event.code + '). Reconnecting in ' + delay + 'ms (attempt ' + this._reconnectAttempts + '/' + this._maxReconnectAttempts + ')');
                        if (this.onStatusChange) this.onStatusChange('connecting');
                        setTimeout(() => this.connect(this.apiKeys, this.sessionConfig, 'network'), delay);
                        return;
                    }
                }

                if (this.onDisconnect) this.onDisconnect(event.code, event.reason);
                if (this.onStatusChange) this.onStatusChange('disconnected');
            };

        } catch (err) {
            console.error('[GVC] Error creating WebSocket:', err);
            this.isConnecting = false;
            if (this.connectionTimeout) {
                clearTimeout(this.connectionTimeout);
                this.connectionTimeout = null;
            }
            if (this.onError) this.onError(err);
            if (this.onStatusChange) this.onStatusChange('error');
        }
    }

    _cleanupConnection() {
        if (this.connectionTimeout) {
            clearTimeout(this.connectionTimeout);
            this.connectionTimeout = null;
        }
        if (this.ws) {
            try {
                this.ws.onopen = null;
                this.ws.onmessage = null;
                this.ws.onerror = null;
                this.ws.onclose = null;
                this.ws.close(1000, 'Cleanup');
            } catch(e) {}
            this.ws = null;
        }
        this.isConnected = false;
        this.isConnecting = false;
    }

    _sendSetup() {
        const voiceName = this.sessionConfig.voiceName || 'Kore';
        const languageCode = this.sessionConfig.languageHint || 'es-ES';
        const language2 = this.sessionConfig.language2 || null;
        const dualMode = this.sessionConfig.dualLanguageMode && language2;

        const systemInstructions = {
            'zh-CN': 'You are a helpful voice assistant. Please respond in natural, clear, and concise Mandarin Chinese.',
            'zh-Hans-CN': 'You are a helpful voice assistant. Please respond in natural, clear, and concise Mandarin Chinese.',
            'es-ES': 'Eres un asistente de voz util y conversacional. Responde de manera natural, clara y concisa en espanol de Espana. Presta especial atencion a nombres propios de peliculas, series y programas de television.',
            'es-419': 'Eres un asistente de voz util y conversacional. Responde de manera natural, clara y concisa en espanol latinoamericano neutro. Usa "tu" en vez de "vos" (no uses voseo rioplatense) y evita modismos o acento argentino, chileno o de cualquier otro pais especifico; mantente en un espanol neutro entendible en toda Latinoamerica. Presta especial atencion a nombres propios de peliculas, series y programas de television.',
            'en-US': 'You are a helpful voice assistant. Respond in a natural, clear, and concise manner in American English.',
            'en-GB': 'You are a helpful voice assistant. Respond in a natural, clear, and concise manner in British English.',
            'pt-BR': 'Voce e um assistente de voz util e conversacional. Responda de forma natural, clara e concisa em portugues brasileiro.',
            'de-DE': 'Du bist ein hilfreicher Sprachassistent. Antworte auf natuerliche, klare und praegnante Weise auf Deutsch.',
            'fr-FR': 'Vous etes un assistant vocal utile. Repondez de maniere naturelle, claire et concise en francais.',
            'it-IT': 'Sei un assistente vocale utile. Rispondi in modo naturale, chiaro e conciso in italiano.',
            'ja-JP': 'あなたは役立つ音声アシスタントです。自然で明確で簡潔な日本語で応答してください。',
            'ko-KR': '당신은 유용한 음성 비서입니다. 자연스럽고 명확하며 간결한 한국어로 응답하세요.',
            'ru-RU': 'Вы полезный голосовой помощник. Отвечайте естественно, четко и кратко на русском языке.',
            'ar-XA': 'أنت مساعد صوتي مفيد. استجب بطريقة طبيعية وواضحة وموجزة باللغة العربية.',
            'hi-IN': 'आप एक उपयोगी वॉयस असिस्टेंट हैं। कृपया प्राकृतिक, स्पष्ट और संक्षिप्त हिंदी में उत्तर दें।',
            'nl-NL': 'Je bent een behulpzame spraakassistent. Reageer op een natuurlijke, duidelijke en beknopte manier in het Nederlands.',
            'tr-TR': 'Yararli bir sesli asistansiniz. Dogal, acik ve oz bir sekilde Turkce yanit verin.',
            'pl-PL': 'Jestes pomocnym asystentem glosowym. Odpowiadaj w naturalny, jasny i zwiezly sposob po polsku.',
            'vi-VN': 'Ban la mot tro ly giong noi huu ich. Tra loi mot cach tu nhien, ro rang va suc tich bang tieng Viet.',
            'th-TH': 'คุณเป็นผู้ช่วยเสียงที่มีประโยชน์ ตอบกลับอย่างเป็นธรรมชาติ ชัดเจน และกระชับเป็นภาษาไทย',
            'id-ID': 'Anda adalah asisten suara yang membantu. Jawab dengan cara yang alami, jelas, dan ringkas dalam bahasa Indonesia.'
        };

        let systemInstruction = this.sessionConfig.systemInstruction ||
            systemInstructions[languageCode] || systemInstructions['es-ES'];

        if (dualMode) {
            const lang1Label = this._langLabel(languageCode);
            const lang2Label = this._langLabel(language2);
            systemInstruction = `Eres un asistente de voz bilingue. El usuario puede hablarte en ${lang1Label} o en ${lang2Label} indistintamente en la misma conversacion. Detecta automaticamente el idioma del usuario y responde SIEMPRE en ese mismo idioma. Si el usuario mezcla idiomas, responde en el que predomine. Se natural, claro y conciso. Si respondes en espanol, usa espanol neutro con "tu" (nunca voseo rioplatense ni modismos de un pais en particular).`;
        }

        const temperature = this.sessionConfig.responseTemperature !== undefined
            ? this.sessionConfig.responseTemperature
            : 0.9;

        const setupMessage = {
            setup: {
                model: 'models/' + (this.sessionConfig.geminiModel || LIVE_MODEL_DEFAULT),
                generationConfig: {
                    responseModalities: ['AUDIO'],
                    temperature: temperature,
                    speechConfig: {
                        languageCode: languageCode,
                        voiceConfig: {
                            prebuiltVoiceConfig: {
                                voiceName: voiceName
                            }
                        }
                    }
                },
                systemInstruction: {
                    parts: [{ text: systemInstruction }]
                }
            }
        };

        if (this.sessionConfig.vadEnabled !== false) {
            setupMessage.setup.realtimeInputConfig = {
                automaticActivityDetection: {
                    disabled: false,
                    startOfSpeechSensitivity: 'START_SENSITIVITY_HIGH',
                    endOfSpeechSensitivity: 'END_SENSITIVITY_LOW',
                    prefixPaddingMs: this.sessionConfig.vadPrefixPaddingMs || 100,
                    silenceDurationMs: this.sessionConfig.vadSilenceDurationMs || 700
                }
            };
        }

        if (this.sessionConfig.showTranscriptions !== false) {
            setupMessage.setup.inputAudioTranscription = {};
            setupMessage.setup.outputAudioTranscription = {};
        }

        // FIX: always request session resumption, and reuse the last handle we
        // were given when reconnecting (goAway or network drop). Without this the
        // conversation's server-side context is lost every time the underlying
        // WebSocket has to reconnect, which is what produced the "freezes / has to
        // repeat itself after a few minutes" symptom on long conversations.
        setupMessage.setup.sessionResumption = this._lastResumptionHandle
            ? { handle: this._lastResumptionHandle }
            : {};

        // FIX: enable context window compression (sliding window). Without this,
        // a long voice conversation keeps accumulating full audio/text history
        // server-side, which is the other main cause of Gemini taking longer and
        // longer to respond (and eventually needing several repeats) the longer
        // the call goes on. This trims older turns automatically once a token
        // threshold is hit, keeping response latency flat over time.
        setupMessage.setup.contextWindowCompression = { slidingWindow: {} };

        if (this.sessionConfig.debugMode) {
            console.log('[GVC] Setup message:', JSON.stringify(setupMessage, null, 2));
        }

        this._sendJSON(setupMessage);
    }

    _scheduleGoAwayReconnect() {
        // Proactively close and reconnect a bit ahead of the server's own cutoff
        // (goAway.timeLeft, when present) instead of waiting to be dropped, so
        // there's no dead air / stuck "connected" UI while the socket is really
        // already on its way out.
        if (this._goAwayReconnectScheduled) return;
        this._goAwayReconnectScheduled = true;
        setTimeout(() => {
            if (this.ws) {
                try { this.ws.close(1000, 'Reconnecting before session time limit'); } catch (e) {}
            }
        }, 500);
    }

    sendAudio(base64PCM) {
        if (!this.isConnected || !this.ws) return;
        this._sendJSON({
            realtimeInput: {
                audio: { data: base64PCM, mimeType: 'audio/pcm;rate=16000' }
            }
        });
    }

    // FIX: when the active API key rotates, the new key opens a brand-new
    // session on Gemini's side — the sessionResumption handle from the old key
    // is NOT valid there, so without this the conversation would silently lose
    // all context (which reads as "the AI forgot everything" / getting slower
    // and needing repeats). We replay the recent transcript as history turns
    // (turnComplete:false — added to context, no extra generation/latency)
    // right after reconnecting, so the model keeps continuity.
    primeHistory(turns) {
        if (!turns || !turns.length || !this.isConnected || !this.ws) return;
        const clientTurns = turns
            .filter(turn => turn && turn.text && (turn.role === 'user' || turn.role === 'model'))
            .map(turn => ({ role: turn.role, parts: [{ text: turn.text }] }));
        if (!clientTurns.length) return;
        this._sendJSON({
            clientContent: { turns: clientTurns, turnComplete: false }
        });
    }

    sendText(text) {
        if (!this.isConnected || !this.ws) return;
        this._sendJSON({
            realtimeInput: { text: text }
        });
    }

    sendFiles(fileChunks) {
        if (!this.isConnected || !this.ws) return false;
        if (!fileChunks || !fileChunks.length) return false;

        const mediaChunks = fileChunks.map(chunk => ({
            mimeType: chunk.mimeType || 'application/octet-stream',
            data: chunk.data
        }));

        this._sendJSON({
            realtimeInput: {
                mediaChunks: mediaChunks
            }
        });

        return true;
    }

    sendImageSeries(imageChunks) {
        if (!this.isConnected || !this.ws) return false;
        if (!imageChunks || !imageChunks.length) return false;

        const mediaChunks = imageChunks.map(chunk => ({
            mimeType: chunk.mimeType || 'image/jpeg',
            data: chunk.data
        }));

        this._sendJSON({
            realtimeInput: {
                mediaChunks: mediaChunks
            }
        });

        return true;
    }

    _sendJSON(obj) {
        if (this.ws && this.ws.readyState === WebSocket.OPEN) {
            this.ws.send(JSON.stringify(obj));
        }
    }

    _handleMessage(data) {
        try {
            let msg = data;
            if (typeof data === 'string') {
                msg = JSON.parse(data);
            } else if (typeof data !== 'object') {
                console.warn('[GVC] Unexpected message type:', typeof data, data);
                return;
            }

            if (this.onMessage) this.onMessage('raw', msg);

            if (msg.setupComplete) {
                console.log('[GVC] Setup completed');
                if (this.onMessage) this.onMessage('setupComplete', msg);
                // FIX: only start sending mic audio / priming history now that the
                // server has actually confirmed setup — doing it right at socket
                // open (before setupComplete) risked those messages arriving
                // before the server was ready for them.
                if (this.onConnect) this.onConnect(this._lastConnectReason);
                return;
            }

            if (msg.serverContent) {
                this._handleServerContent(msg.serverContent);
                return;
            }

            if (msg.toolCall) {
                if (this.onMessage) this.onMessage('toolCall', msg.toolCall);
                return;
            }

            if (msg.usageMetadata) {
                if (this.onMessage) this.onMessage('usage', msg.usageMetadata);
                return;
            }

            if (msg.goAway) {
                // FIX: Gemini Live sessions have a hard time limit and warn via goAway
                // shortly before force-closing the socket. Previously nothing was done
                // about it, so after ~a few minutes the connection would die and the
                // user had to notice/reconnect manually (perceived as "freezing" or
                // needing to repeat themselves). Now we proactively reconnect (reusing
                // the session resumption handle when available) BEFORE the server cuts
                // us off, so the conversation continues without the user noticing.
                console.warn('[GVC] Server sent goAway:', msg.goAway);
                this._goAwayReceived = true;
                if (this.onMessage) this.onMessage('goAway', msg.goAway);
                this._scheduleGoAwayReconnect();
                return;
            }

            if (msg.sessionResumptionUpdate) {
                // FIX: store the resumption handle so a reconnect (goAway or network
                // drop) can resume the same logical session instead of starting a
                // brand-new one with no context.
                const update = msg.sessionResumptionUpdate;
                if (update && update.resumable && update.newHandle) {
                    this._lastResumptionHandle = update.newHandle;
                }
                if (this.onMessage) this.onMessage('resumption', update);
                return;
            }

        } catch (err) {
            console.error('[GVC] Error parsing message:', err, data);
        }
    }

    _handleServerContent(content) {
        if (content.modelTurn && content.modelTurn.parts) {
            // Deduplicación por turno: track de parts ya procesadas en este modelTurn
            const processedParts = new Set();
            for (const part of content.modelTurn.parts) {
                // Crear firma de la part para deduplicación intra-turno
                let partSig = '';
                if (part.inlineData && part.inlineData.data) {
                    partSig = 'audio:' + part.inlineData.data.substring(0, 100);
                } else if (part.text) {
                    partSig = 'text:' + part.text;
                }
                if (partSig && processedParts.has(partSig)) {
                    console.log('[GVC] Duplicate part within same modelTurn ignored');
                    continue;
                }
                if (partSig) processedParts.add(partSig);

                if (part.inlineData && part.inlineData.data) {
                    const mimeType = part.inlineData.mimeType || '';
                    if (mimeType.includes('audio') || !mimeType) {
                        const rateMatch = mimeType.match(/rate=(\d+)/);
                        const sampleRate = rateMatch ? parseInt(rateMatch[1]) : 24000;
                        if (this.onAudioOutput) this.onAudioOutput(part.inlineData.data, sampleRate);
                    }
                }
                if (part.text) {
                    if (this.onTranscription) this.onTranscription(part.text, false);
                }
            }
        }

        if (content.turnComplete) {
            if (this.onMessage) this.onMessage('turnComplete', content);
        }
        if (content.generationComplete) {
            if (this.onMessage) this.onMessage('generationComplete', content);
        }
        if (content.interrupted) {
            if (this.onMessage) this.onMessage('interrupted', content);
        }
        if (content.inputTranscription && content.inputTranscription.text) {
            if (this.onTranscription) this.onTranscription(content.inputTranscription.text, true);
        }
        if (content.outputTranscription && content.outputTranscription.text) {
            if (this.onTranscription) this.onTranscription(content.outputTranscription.text, false);
        }
    }

    disconnect() {
        this._intentionalDisconnect = true;
        this._reconnectAttempts = 0;
        this._goAwayReceived = false;
        this._goAwayReconnectScheduled = false;
        this._lastResumptionHandle = null; // manual disconnect starts a fresh session next time
        if (this.connectionTimeout) {
            clearTimeout(this.connectionTimeout);
            this.connectionTimeout = null;
        }
        if (this.ws) {
            try { this.ws.close(1000, 'Manual disconnect'); } catch(e) {}
            this.ws = null;
        }
        this.isConnected = false;
        this.isConnecting = false;
    }

    _langLabel(code) {
        const labels = {
            'es-ES': 'espanol', 'es-419': 'espanol latinoamericano', 'en-US': 'ingles',
            'en-GB': 'ingles britanico', 'pt-BR': 'portugues', 'de-DE': 'aleman',
            'fr-FR': 'frances', 'it-IT': 'italiano', 'zh-CN': 'chino mandarin',
            'ja-JP': 'japones', 'ko-KR': 'coreano', 'ru-RU': 'ruso',
            'ar-XA': 'arabe', 'hi-IN': 'hindi', 'nl-NL': 'neerlandes',
            'tr-TR': 'turco', 'pl-PL': 'polaco', 'vi-VN': 'vietnamita',
            'th-TH': 'tailandes', 'id-ID': 'indonesio'
        };
        return labels[code] || code;
    }
}

// ============================================
// MIC DIAGNOSTICS (adapted for Chrome extension)
// ============================================

class MicDiagnostics {
  static async run(settings) {
    const issues = [];
    let devices = [];
    let stream = null;

    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      issues.push({
        code: 'no-media-api',
        title: currentLang === 'en' ? 'Microphone API not available' : 'La API de microfono no esta disponible',
        detail: currentLang === 'en' ? 'This browser does not expose navigator.mediaDevices in this context.' : 'Este navegador no expone navigator.mediaDevices en este contexto.',
        fixes: []
      });
      return { ok: false, issues, devices };
    }

    try {
      devices = (await navigator.mediaDevices.enumerateDevices()).filter(d => d.kind === 'audioinput');
    } catch (e) { /* retry below */ }

    if (devices.length === 0) {
      issues.push({
        code: 'no-devices',
        title: currentLang === 'en' ? 'No microphone detected' : 'No se detecta ningun microfono',
        detail: currentLang === 'en' ? 'The system reports no audio input devices. It may be disconnected or disabled.' : 'El sistema no reporta ningun dispositivo de entrada de audio. Puede estar desconectado o deshabilitado.',
        fixes: MicDiagnostics._settingsFix()
      });
    }

    try {
      const constraints = { audio: { channelCount: 1 } };
      if (settings && settings.preferredMicDeviceId) {
        constraints.audio.deviceId = { exact: settings.preferredMicDeviceId };
      }
      stream = await navigator.mediaDevices.getUserMedia(constraints);
    } catch (err) {
      const name = err && err.name;
      if (name === 'NotAllowedError' || name === 'PermissionDeniedError') {
        issues.push({
          code: 'permission-denied',
          title: currentLang === 'en' ? 'Microphone permission denied' : 'Permiso de microfono denegado',
          detail: currentLang === 'en' ? 'Chrome is blocking microphone access for this extension.' : 'Chrome esta bloqueando el acceso al microfono para esta extension.',
          fixes: MicDiagnostics._settingsFix()
        });
      } else if (name === 'NotFoundError' || name === 'OverconstrainedError') {
        issues.push({
          code: 'device-not-found',
          title: currentLang === 'en' ? 'Configured microphone no longer exists' : 'El microfono configurado ya no existe',
          detail: currentLang === 'en' ? 'The device disconnected or changed name.' : 'El dispositivo se desconecto o cambio de nombre.',
          fixes: MicDiagnostics._settingsFix()
        });
      } else if (name === 'NotReadableError' || name === 'TrackStartError') {
        issues.push({
          code: 'device-busy',
          title: currentLang === 'en' ? 'Microphone is busy or blocked' : 'El microfono esta ocupado o bloqueado',
          detail: currentLang === 'en' ? 'Another application may have the microphone in exclusive use, or the audio driver is failing.' : 'Otra aplicacion puede tener el microfono en uso exclusivo, o el driver de audio esta fallando.',
          fixes: MicDiagnostics._settingsFix()
        });
      } else {
        issues.push({
          code: 'unknown-error',
          title: currentLang === 'en' ? 'Error accessing microphone' : 'Error accediendo al microfono',
          detail: (name || 'Error') + ': ' + (err && err.message ? err.message : String(err)),
          fixes: MicDiagnostics._settingsFix()
        });
      }
      return { ok: false, issues, devices };
    }

    try {
      devices = (await navigator.mediaDevices.enumerateDevices()).filter(d => d.kind === 'audioinput');
    } catch (e) { /* not critical */ }

    const track = stream.getAudioTracks()[0];
    if (track) {
      if (track.muted) {
        issues.push({
          code: 'track-muted',
          title: currentLang === 'en' ? 'Microphone is muted at system level' : 'El microfono esta silenciado a nivel de sistema',
          detail: currentLang === 'en' ? 'The operating system marks the device as "muted". Usually because the capture level is at 0.' : 'El sistema operativo marca el dispositivo como "muted". Suele deberse a que el nivel de captura esta en 0.',
          fixes: MicDiagnostics._settingsFix()
        });
      }

      const peak = await MicDiagnostics._measurePeakLevel(stream, 1200);
      if (peak < 0.002) {
        issues.push({
          code: 'silent-signal',
          title: currentLang === 'en' ? 'Microphone captured no sound during test' : 'El microfono no capto ningun sonido en la prueba',
          detail: currentLang === 'en' ? 'The device opened correctly but the level remained at total silence. Check the capture level or the system default microphone.' : 'El dispositivo se abrio correctamente pero el nivel se mantuvo en silencio total. Revisa el nivel de captura o el microfono predeterminado del sistema.',
          fixes: MicDiagnostics._settingsFix()
        });
      }
    }

    try { stream.getTracks().forEach(t => t.stop()); } catch (e) {}

    if (devices.length > 1) {
      issues.push({
        code: 'multiple-devices',
        title: currentLang === 'en' ? devices.length + ' microphones available' : 'Hay ' + devices.length + ' microfonos disponibles',
        detail: currentLang === 'en' ? 'If the assistant still cannot hear well, a different device than expected may be in use. Choose the correct one below.' : 'Si el asistente sigue sin escuchar bien, es posible que se este usando un dispositivo distinto al esperado. Elige el correcto abajo.',
        fixes: [],
        info: true
      });
    }

    return { ok: issues.filter(i => !i.info).length === 0, issues, devices };
  }

  static _measurePeakLevel(stream, ms) {
    return new Promise((resolve) => {
      try {
        const AC = window.AudioContext || window.webkitAudioContext;
        const ctx = new AC();
        const source = ctx.createMediaStreamSource(stream);
        const analyser = ctx.createAnalyser();
        analyser.fftSize = 2048;
        source.connect(analyser);
        const data = new Float32Array(analyser.fftSize);
        let peak = 0;
        const start = Date.now();
        const tick = () => {
          analyser.getFloatTimeDomainData(data);
          let sum = 0;
          for (let i = 0; i < data.length; i++) sum += data[i] * data[i];
          const rms = Math.sqrt(sum / data.length);
          if (rms > peak) peak = rms;
          if (Date.now() - start < ms) {
            requestAnimationFrame(tick);
          } else {
            try { ctx.close(); } catch (e) {}
            resolve(peak);
          }
        };
        tick();
      } catch (e) {
        resolve(1);
      }
    });
  }

  static _settingsFix() {
    return [{ label: currentLang === 'en' ? 'Open Chrome microphone settings' : 'Abrir configuracion de microfono de Chrome', action: 'open-mic-settings' }];
  }

  static openBrowserSetting(action) {
    if (action === 'open-mic-settings') {
      chrome.tabs.create({ url: 'chrome://settings/content/microphone' }).catch(() => {});
    }
  }
}

// ============================================
// UI CONTROLLER (side panel) — PATCHED
// ============================================
// Fixes:
// - i18n support (es/en)
// - Bubble cleanup on all events
// - Proper attachment handling
// - Donation copy-to-clipboard
// - Reconnection handling

document.addEventListener('DOMContentLoaded', () => {

  let settings = Object.assign({}, DEFAULT_SETTINGS);
  const audioManager = new AudioManager(settings);
  const client = new GeminiLiveClient();

  let isVoiceActive = false;
  let currentUserBubble = null;
  let currentModelBubble = null;

  // ---------- refs ----------
  const statusDot = document.getElementById('status-dot');
  const statusText = document.getElementById('status-text');

  const tabBtns = {
    chat: document.getElementById('tab-btn-chat'),
    settings: document.getElementById('tab-btn-settings')
  };
  const panels = {
    chat: document.getElementById('panel-chat'),
    settings: document.getElementById('panel-settings')
  };

  const transcript = document.getElementById('transcript');
  const btnVoice = document.getElementById('btn-voice');
  const textInput = document.getElementById('text-input');
  const btnSend = document.getElementById('btn-send');

  const diagBody = document.getElementById('diag-body');
  const diagLogsEl = document.getElementById('diag-logs');
  const btnFix = document.getElementById('btn-fix');
  const btnAnalyze = document.getElementById('btn-analyze');
  const subtabDiag = document.getElementById('subtab-diag');
  const subtabLogs = document.getElementById('subtab-logs');

  const apiKeysEl = document.getElementById('api-keys');
  const btnSaveKeys = document.getElementById('btn-save-keys');
  const voiceSelect = document.getElementById('voice-select');
  const langSelect = document.getElementById('lang-select');
  const dualLangToggle = document.getElementById('dual-lang-toggle');
  const lang2Select = document.getElementById('lang2-select');
  const vadToggle = document.getElementById('vad-toggle');
  const vadSilenceSlider = document.getElementById('vad-silence');
  const vadSilenceValue = document.getElementById('vad-silence-value');
  const tempRange = document.getElementById('temp-range');
  const tempValue = document.getElementById('temp-value');
  const modelInput = document.getElementById('model-input');
  const btnSaveSettings = document.getElementById('btn-save-settings');
  const btnDetectModel = document.getElementById('btn-detect-model');
  const modelDetectStatus = document.getElementById('model-detect-status');
  const saveConversationToggle = document.getElementById('save-conversation-toggle');
  const btnDownloadChat = document.getElementById('btn-download-chat');
  const volumeBarFill = document.getElementById('volume-bar-fill');
  const uiLangSelect = document.getElementById('ui-lang-select');
  const btnSaveUiLang = document.getElementById('btn-save-ui-lang');

  // ---------- i18n ----------
  function applyI18n() {
    tabBtns.chat.textContent = t('tabChat');
    tabBtns.settings.textContent = t('tabSettings');
    subtabDiag.textContent = t('subtabDiag');
    subtabLogs.textContent = t('subtabLogs');
    btnVoice.textContent = isVoiceActive ? t('stop') : t('speak');
    btnSend.textContent = t('send');
    btnAnalyze.textContent = t('analyze');
    btnFix.textContent = t('fix');
    btnSaveKeys.textContent = t('saveKeys');
    btnSaveSettings.textContent = t('saveSettings');
    btnSaveUiLang.textContent = t('saveLang');
    textInput.placeholder = t('textPlaceholder');
    document.getElementById('drop-hint').textContent = t('dragHint');

    // FIX: the language switcher used to only translate a handful of chat
    // elements — the whole Settings tab stayed in Spanish no matter what you
    // picked. Wire up every remaining static label/hint/title so picking
    // English actually translates the full interface.
    const byId = (id) => document.getElementById(id);
    const setText = (id, key) => { const el = byId(id); if (el) el.textContent = t(key); };
    const setHtml = (id, key) => { const el = byId(id); if (el) el.innerHTML = t(key); };

    setText('h3-ui-lang', 'interfaceLang');
    setText('hint-ui-lang', 'interfaceLangHint');
    byId('btn-attach').title = t('attachTitle');
    byId('btn-download-chat').title = t('downloadTitle');
    byId('volume-bar-wrap').title = t('volumeTitle');

    setText('h3-api-keys', 'apiKeysTitle');
    setText('api-hint-1', 'apiKeyHint1');
    setText('api-hint-2', 'apiKeyHint2');
    setHtml('api-hint-3', 'apiKeyHint3-html');
    setText('api-key-example', 'apiKeyExample');
    setText('api-hint-4', 'apiKeyHint6');
    apiKeysEl.placeholder = t('apiKeysPlaceholder');

    setText('h3-voice-lang', 'voiceLangTitle');
    setText('label-voice', 'voiceLabel');
    setText('label-lang1', 'mainLang');
    setText('label-bilingual', 'bilingualMode');
    setHtml('info-dual-lang', 'infoDualLang');
    setText('label-lang2', 'secondLang');

    setText('h3-vad', 'vadTitle');
    setText('label-vad-auto', 'vadAuto');
    setText('hint-vad', 'vadHint');
    setText('label-silence-text', 'silenceLabel');
    setText('hint-silence', 'silenceHint');
    setText('label-temp-text', 'tempLabel');
    setHtml('info-temp', 'infoTemp');
    setText('h3-model-text', 'modelLabel');
    setHtml('info-model', 'infoModel');
    setText('label-model-name', 'modelNameLabel');
    byId('btn-detect-model').textContent = t('detectModelBtn');

    setText('h3-conv', 'convLabel');
    setText('label-save-conv', 'saveConvLabel');
    setText('hint-save-conv', 'saveConvHint');

    setText('h3-mic-howto', 'micHowToTitle');
    setHtml('mic-step-1', 'micStep1');
    setHtml('mic-step-2', 'micStep2');
    setHtml('mic-step-3', 'micStep3');
    setHtml('mic-step-4', 'micStep4');

    byId('h3-donation').innerHTML = '💚 ' + t('donationTitle');
    setText('creator-degree', 'creatorDegree');
    byId('donation-label-paypal').innerHTML = '🌐 ' + t('paypalLabel');
    setText('donation-note-paypal', 'paypalNote');
  }

  // ---------- tabs ----------
  function switchTab(name) {
    Object.keys(panels).forEach(k => {
      panels[k].classList.toggle('active', k === name);
      tabBtns[k].classList.toggle('active', k === name);
    });
  }
  tabBtns.chat.addEventListener('click', () => switchTab('chat'));
  tabBtns.settings.addEventListener('click', () => switchTab('settings'));

  // ---------- persistencia ----------
  function loadSettings() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['gvcSettings'], (result) => {
        settings = Object.assign({}, DEFAULT_SETTINGS, result.gvcSettings || {});
        currentLang = settings.uiLanguage || 'es';
        audioManager.settings = settings;
        resolve(settings);
      });
    });
  }

  function saveSettings() {
    return new Promise((resolve) => {
      chrome.storage.local.set({ gvcSettings: settings }, resolve);
    });
  }

  function applySettingsToUI() {
    apiKeysEl.value = (settings.geminiApiKeys || []).join('\n');
    voiceSelect.value = settings.voiceName || 'Kore';
    langSelect.value = settings.languageHint || 'es-ES';
    dualLangToggle.checked = !!settings.dualLanguageMode;
    lang2Select.value = settings.language2 || 'en-US';
    vadToggle.checked = settings.vadEnabled !== false;
    vadSilenceSlider.value = settings.vadSilenceDurationMs || 700;
    vadSilenceValue.textContent = String(settings.vadSilenceDurationMs || 700);
    tempRange.value = settings.responseTemperature !== undefined ? settings.responseTemperature : 0.9;
    tempValue.textContent = String(tempRange.value);
    modelInput.value = settings.geminiModel || LIVE_MODEL_DEFAULT;
    saveConversationToggle.checked = !!settings.saveConversation;
    uiLangSelect.value = settings.uiLanguage || 'es';
    applyI18n();
  }

  // ---------- botones de ayuda (?) ----------
  document.querySelectorAll('.info-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const target = document.getElementById(btn.getAttribute('data-target'));
      if (!target) return;
      target.style.display = target.style.display === 'none' ? '' : 'none';
    });
  });

  vadSilenceSlider.addEventListener('input', () => {
    vadSilenceValue.textContent = vadSilenceSlider.value;
  });
  tempRange.addEventListener('input', () => {
    tempValue.textContent = tempRange.value;
  });

  btnSaveKeys.addEventListener('click', async () => {
    const keys = apiKeysEl.value.split('\n').map(k => k.trim()).filter(Boolean);
    settings.geminiApiKeys = keys;
    settings.activeApiKeyIndex = 0;
    await saveSettings();
    addSystemMessage(t('keysSaved') + ' (' + keys.length + ').');
  });

  btnSaveUiLang.addEventListener('click', async () => {
    settings.uiLanguage = uiLangSelect.value;
    currentLang = settings.uiLanguage;
    await saveSettings();
    applyI18n();
    addSystemMessage(t('langSaved') + '.');
  });

  btnSaveSettings.addEventListener('click', async () => {
    settings.voiceName = voiceSelect.value;
    settings.languageHint = langSelect.value;
    settings.dualLanguageMode = dualLangToggle.checked;
    settings.language2 = lang2Select.value;
    settings.vadEnabled = vadToggle.checked;
    settings.vadSilenceDurationMs = parseInt(vadSilenceSlider.value, 10);
    settings.responseTemperature = parseFloat(tempRange.value);
    settings.geminiModel = modelInput.value.trim() || LIVE_MODEL_DEFAULT;
    settings.saveConversation = saveConversationToggle.checked;
    await saveSettings();
    if (!settings.saveConversation) {
      chrome.storage.local.remove('gvcConversation');
    }
    addSystemMessage(t('settingsSaved'));
  });

  // ---------- deteccion automatica ----------
  btnDetectModel.addEventListener('click', async () => {
    const key = (settings.geminiApiKeys && settings.geminiApiKeys[0]) || '';
    if (!key) {
      modelDetectStatus.textContent = t('saveKeyFirst');
      return;
    }
    modelDetectStatus.textContent = t('searchingModels');
    btnDetectModel.disabled = true;
    try {
      const res = await fetch('https://generativelanguage.googleapis.com/v1beta/models?key=' + encodeURIComponent(key));
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const data = await res.json();
      const models = (data.models || []).filter(m =>
        (m.supportedGenerationMethods || []).includes('bidiGenerateContent') ||
        /live/i.test(m.name)
      );
      if (!models.length) {
        modelDetectStatus.textContent = t('noModelFound');
        return;
      }

      // FIX: previously this always overwrote whatever model name was set
      // (e.g. gemini-3.1-flash-live-preview) with its own pick, even when the
      // current one was perfectly fine and still listed by the API. Now it
      // only replaces the model if the current one is NOT in the available
      // list anymore.
      const currentModel = (modelInput.value || settings.geminiModel || LIVE_MODEL_DEFAULT).trim();
      const currentStillAvailable = models.some(m => m.name.replace(/^models\//, '') === currentModel);
      if (currentStillAvailable) {
        modelDetectStatus.textContent = t('modelStillAvailable') + ': ' + currentModel + '.';
        return;
      }

      const chosen = models.find(m => /flash/i.test(m.name)) || models[0];
      const modelId = chosen.name.replace(/^models\//, '');
      modelInput.value = modelId;
      modelDetectStatus.textContent = t('modelDetected') + ': ' + modelId + '. ' + t('rememberSave');
    } catch (err) {
      modelDetectStatus.textContent = t('modelQueryError') + ' (' + (err.message || err) + ').';
    } finally {
      btnDetectModel.disabled = false;
    }
  });

  // ---------- chat ----------
  const conversationLog = [];

  function addMessage(role, text) {
    const bubble = document.createElement('div');
    bubble.className = 'msg ' + role;
    bubble.textContent = text;
    transcript.appendChild(bubble);
    transcript.scrollTop = transcript.scrollHeight;

    if (role !== 'system') {
      const logEntry = { role, text, time: new Date().toISOString() };
      conversationLog.push(logEntry);
      // BUGFIX: streamed transcriptions (voice) update the bubble's DOM text
      // via appendToMessage() below, but conversationLog kept the original
      // (often empty) string forever, since a plain string copy doesn't track
      // later mutations. That silently broke: downloading the conversation
      // (blank lines for every voice turn), restoring a saved conversation
      // (blank bubbles), and primeHistory() on key rotation (empty-text turns
      // get filtered out, so the "don't forget context" fix never had any
      // real text to replay). Keep a reference to the log entry on the bubble
      // so streaming updates can keep both in sync.
      bubble._logEntry = logEntry;
      if (settings.saveConversation) persistConversation();
    }
    return bubble;
  }

  // Appends streamed text to a bubble AND keeps conversationLog in sync.
  function appendToMessage(bubble, text) {
    bubble.textContent += text;
    if (bubble._logEntry) {
      bubble._logEntry.text += text;
    }
  }

  function persistConversation() {
    chrome.storage.local.set({ gvcConversation: conversationLog });
  }

  function restoreConversation() {
    chrome.storage.local.get(['gvcConversation'], (result) => {
      const saved = result.gvcConversation || [];
      if (!saved.length) return;
      saved.forEach(m => {
        conversationLog.push(m);
        const bubble = document.createElement('div');
        bubble.className = 'msg ' + m.role;
        bubble.textContent = m.text;
        transcript.appendChild(bubble);
      });
      transcript.scrollTop = transcript.scrollHeight;
      addSystemMessage(t('restoredConv'));
    });
  }

  btnDownloadChat.addEventListener('click', () => {
    if (!conversationLog.length) {
      addSystemMessage(t('noConvToDownload'));
      return;
    }
    const lines = conversationLog.map(m => {
      const who = m.role === 'user' ? 'Yo' : 'Gemini';
      return '[' + new Date(m.time).toLocaleString() + '] ' + who + ': ' + m.text;
    });
    const blob = new Blob([lines.join('\n\n')], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'gemini-voice-chat-' + Date.now() + '.txt';
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  });

  function addSystemMessage(text) {
    addMessage('system', text);
  }

  function setStatus(state) {
    statusDot.className = 'status-dot';
    if (state === 'connected') {
      statusDot.classList.add('connected');
      statusText.textContent = t('connected');
    } else if (state === 'connecting') {
      statusDot.classList.add('connecting');
      statusText.textContent = t('connecting');
    } else if (state === 'rotating') {
      statusDot.classList.add('connecting');
      statusText.textContent = t('rotating');
    } else if (state === 'error') {
      statusDot.classList.add('error');
      statusText.textContent = t('errorConnection');
    } else {
      statusText.textContent = t('disconnected');
    }
  }

  client.onStatusChange = (state) => setStatus(state);

  client.onConnect = async (reason) => {
    audioManager.stopPlayback();      // cortar audio anterior inmediatamente
    clearAudioQueue();                   // limpiar cola de audio anterior
    _audioChunkCounter = 0;              // resetear contador de chunks para nueva sesión
    // NOTA: no limpiamos hashes aqui. Si el servidor retransmite chunks del
    // turno anterior justo despues de reconectar, queremos detectarlos como
    // duplicados. Los hashes se limpian solo al detener manualmente.
    addSystemMessage(t('connectedMsg'));

    // FIX: previously the mic was re-acquired (getUserMedia + new AudioContext
    // nodes) on every single reconnect, including automatic ones (key rotation,
    // goAway, network blip). That's slow and is itself part of why things felt
    // like they were "hanging" for a bit after a reconnect. If capture is
    // already running, just keep using it — only the WebSocket needed to be
    // replaced.
    if (!audioManager.isCapturing) {
      const ok = await audioManager.startCapture(
        (base64Chunk) => client.sendAudio(base64Chunk),
        (rms) => updateVolumeBar(rms)
      );
      if (!ok) {
        addSystemMessage(t('micError'));
        switchTab('settings');
        return;
      }
    }

    // FIX: after a key-rotation reconnect the new key starts a fresh session
    // with no memory of the conversation. Replay recent turns as silent
    // context so the model doesn't "forget" and the user doesn't have to
    // re-explain themselves.
    if (reason === 'key-rotation' && conversationLog.length) {
      client.primeHistory(conversationLog.slice(-16));
    }
  };

  function updateVolumeBar(rms) {
    const pct = Math.min(100, Math.round((rms / 0.2) * 100));
    volumeBarFill.style.width = pct + '%';
  }

  client.onDisconnect = () => {
    audioManager.stopCapture();
    audioManager.stopPlayback();      // detener audio inmediatamente
    audioManager.clearRecentHashes(); // resetear deduplicación para próxima sesión
    clearAudioQueue();                // limpiar cola de audio pendiente
    _audioChunkCounter = 0;           // resetear contador de chunks
    isVoiceActive = false;
    btnVoice.textContent = t('speak');
    btnVoice.classList.remove('recording');
    updateVolumeBar(0);
    addSystemMessage(t('convEnded'));
  };

  client.onError = (err) => {
    addSystemMessage('Error: ' + (err && err.message ? err.message : String(err)));
  };

  client.onAudioOutput = (base64Data, sampleRate) => {
    enqueueAudio(base64Data, sampleRate);
  };

  // Contador global de chunks de audio para deduplicación por índice
  let _audioChunkCounter = 0;

  // Cola de audio para reproducción secuencial estricta
  let _audioQueue = [];
  let _isPlayingAudio = false;

  function _playNextAudio() {
    if (_audioQueue.length === 0) {
      _isPlayingAudio = false;
      return;
    }
    _isPlayingAudio = true;
    const { base64Data, sampleRate, chunkIndex } = _audioQueue.shift();
    const source = audioManager.playPCM(base64Data, sampleRate, chunkIndex);
    if (source) {
      source.onended = () => {
        _playNextAudio();
      };
    } else {
      // Si playPCM devolvió null (duplicado), seguir con el siguiente
      setTimeout(_playNextAudio, 0);
    }
  }

  function enqueueAudio(base64Data, sampleRate) {
    const chunkIndex = _audioChunkCounter++;
    _audioQueue.push({ base64Data, sampleRate, chunkIndex });
    if (!_isPlayingAudio) {
      _playNextAudio();
    }
  }

  function clearAudioQueue() {
    _audioQueue = [];
    _isPlayingAudio = false;
  }

  client.onTranscription = (text, isInput) => {
    if (isInput) {
      if (!currentUserBubble) currentUserBubble = addMessage('user', '');
      appendToMessage(currentUserBubble, text);
    } else {
      if (!currentModelBubble) currentModelBubble = addMessage('model', '');
      appendToMessage(currentModelBubble, text);
    }
    transcript.scrollTop = transcript.scrollHeight;
  };

  client.onMessage = (type) => {
    if (type === 'turnComplete' || type === 'interrupted' || type === 'generationComplete') {
      if (type === 'interrupted') {
        audioManager.stopPlayback();        // cortar audio inmediatamente
        clearAudioQueue();                   // limpiar cola de audio pendiente
        _audioChunkCounter = 0;              // resetear contador para nuevo turno
      }
      currentUserBubble = null;
      currentModelBubble = null;
      // BUGFIX: persist once the streamed turn is actually finished, now that
      // conversationLog holds the real transcribed text instead of ''.
      if (settings.saveConversation) persistConversation();
    }
  };

  client.onKeyRotated = (index, total) => {
    addSystemMessage(t('keyRotated') + ' ' + (index + 1) + ' ' + t('of') + ' ' + total + '.');
  };

  function buildSessionConfig() {
    return {
      geminiModel: settings.geminiModel,
      voiceName: settings.voiceName,
      languageHint: settings.languageHint,
      language2: settings.language2,
      dualLanguageMode: settings.dualLanguageMode,
      responseTemperature: settings.responseTemperature,
      vadEnabled: settings.vadEnabled,
      vadPrefixPaddingMs: settings.vadPrefixPaddingMs,
      vadSilenceDurationMs: settings.vadSilenceDurationMs,
      showTranscriptions: settings.showTranscriptions
    };
  }

  btnVoice.addEventListener('click', () => {
    if (isVoiceActive) {
      client.disconnect();
      audioManager.stopCapture();
      isVoiceActive = false;
      btnVoice.textContent = t('speak');
      btnVoice.classList.remove('recording');
      return;
    }
    if (!settings.geminiApiKeys || !settings.geminiApiKeys.length) {
      addSystemMessage(t('missingApiKey'));
      switchTab('settings');
      return;
    }
    isVoiceActive = true;
    btnVoice.textContent = t('stop');
    btnVoice.classList.add('recording');
    client.connect(settings.geminiApiKeys, buildSessionConfig());
  });

  function sendTextMessage() {
    const value = textInput.value.trim();
    if (!client.isConnected && (value || attachedFiles.length)) {
      addSystemMessage(t('connectFirst'));
      return;
    }
    if (attachedFiles.length) flushAttachments();
    if (!value) return;
    addMessage('user', value);
    client.sendText(value);
    textInput.value = '';
  }
  btnSend.addEventListener('click', sendTextMessage);
  textInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') sendTextMessage();
  });

  // ---------- adjuntos ----------
  const attachedFiles = [];
  const attachmentsEl = document.getElementById('attachments');
  const btnAttach = document.getElementById('btn-attach');
  const fileInput = document.getElementById('file-input');

  function fileToBase64(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result).split(',')[1] || '');
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }

  async function addAttachment(file) {
    if (!file || file.size === 0) return;
    const MAX_BYTES = 15 * 1024 * 1024;
    if (file.size > MAX_BYTES) {
      addSystemMessage('"' + file.name + '" ' + t('fileTooBig'));
      return;
    }
    try {
      const base64 = await fileToBase64(file);
      const entry = {
        name: file.webkitRelativePath || file.name,
        mimeType: file.type || 'application/octet-stream',
        data: base64
      };
      attachedFiles.push(entry);
      renderAttachments();
    } catch (e) {
      addSystemMessage(t('fileReadError') + ' "' + file.name + '".');
    }
  }

  function removeAttachment(index) {
    attachedFiles.splice(index, 1);
    renderAttachments();
  }

  function renderAttachments() {
    attachmentsEl.innerHTML = '';
    attachedFiles.forEach((f, i) => {
      const chip = document.createElement('div');
      chip.className = 'attachment-chip';
      const name = document.createElement('span');
      name.className = 'name';
      name.textContent = f.name;
      name.title = f.name;
      const remove = document.createElement('button');
      remove.textContent = '✕';
      remove.addEventListener('click', () => removeAttachment(i));
      chip.appendChild(name);
      chip.appendChild(remove);
      attachmentsEl.appendChild(chip);
    });
  }

  btnAttach.addEventListener('click', () => fileInput.click());

  fileInput.addEventListener('change', async () => {
    for (const file of Array.from(fileInput.files)) await addAttachment(file);
    fileInput.value = '';
  });

  ['dragenter', 'dragover'].forEach(evt => {
    transcript.addEventListener(evt, (e) => {
      e.preventDefault();
      transcript.classList.add('drag-over');
    });
  });
  ['dragleave', 'drop'].forEach(evt => {
    transcript.addEventListener(evt, (e) => {
      if (evt === 'drop') e.preventDefault();
      transcript.classList.remove('drag-over');
    });
  });
  transcript.addEventListener('drop', async (e) => {
    e.preventDefault();
    const items = e.dataTransfer && e.dataTransfer.items;
    if (!items || !items.length) return;
    let totalFiles = 0;
    let skippedFolder = false;
    for (const item of Array.from(items)) {
      const entry = item.webkitGetAsEntry ? item.webkitGetAsEntry() : null;
      if (entry && entry.isDirectory) {
        // FIX: folder attachment removed — ignore dropped directories instead
        // of silently reading and attaching every file inside them.
        skippedFolder = true;
        continue;
      }
      const file = (entry && entry.isFile) ? await new Promise(r => entry.file(r)) : (item.getAsFile ? item.getAsFile() : null);
      if (file) { await addAttachment(file); totalFiles++; }
    }
    if (totalFiles > 1) addSystemMessage(totalFiles + ' ' + t('filesAttached') + '.');
    if (skippedFolder) addSystemMessage(t('folderNotSupported'));
  });

  function flushAttachments() {
    if (!attachedFiles.length) return;
    if (!client.isConnected) {
      addSystemMessage(t('connectFirst'));
      return;
    }
    const names = attachedFiles.map(f => f.name).join(', ');
    try {
      client.sendFiles(attachedFiles);
      addMessage('user', '📎 ' + names);
      attachedFiles.length = 0;
      renderAttachments();
    } catch (e) {
      addSystemMessage('Error sending attachments.');
    }
  }

    // ---------- donaciones: copiar al portapapeles ----------
  document.querySelectorAll('.donation-value.copyable').forEach(el => {
    el.style.cursor = 'pointer';
    el.addEventListener('click', () => {
      const text = el.textContent.trim();
      navigator.clipboard.writeText(text).then(() => {
        addSystemMessage(t('copied') + ': ' + text);
      }).catch(() => {
        const ta = document.createElement('textarea');
        ta.value = text;
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        document.body.removeChild(ta);
        addSystemMessage(t('copied') + ': ' + text);
      });
    });
  });


  // ---------- diagnostico ----------
  const diagLogsList = [];
  let lastReport = null;

  function addDiagLog(msg) {
    const time = new Date().toLocaleTimeString();
    diagLogsList.push('[' + time + '] ' + msg);
    diagLogsEl.textContent = diagLogsList.join('\n');
  }

  subtabDiag.addEventListener('click', () => {
    subtabDiag.classList.add('active');
    subtabLogs.classList.remove('active');
    diagBody.style.display = '';
    diagLogsEl.style.display = 'none';
  });
  subtabLogs.addEventListener('click', () => {
    subtabLogs.classList.add('active');
    subtabDiag.classList.remove('active');
    diagBody.style.display = 'none';
    diagLogsEl.style.display = '';
  });

  function renderIntro() {
    diagBody.innerHTML = '';
    const p = document.createElement('div');
    p.className = 'diag-intro';
    p.textContent = t('introText');
    diagBody.appendChild(p);
  }

  function renderLoading(text) {
    diagBody.innerHTML = '';
    const p = document.createElement('div');
    p.className = 'diag-intro';
    p.textContent = text;
    diagBody.appendChild(p);
  }

  function renderIssue(issue) {
    const card = document.createElement('div');
    card.className = 'issue-card' + (issue.info ? ' info' : '');

    const t1 = document.createElement('div');
    t1.className = 'issue-title';
    t1.textContent = issue.title;
    card.appendChild(t1);

    const d = document.createElement('div');
    d.className = 'issue-detail';
    d.textContent = issue.detail;
    card.appendChild(d);

    if (issue.fixes && issue.fixes.length) {
      const row = document.createElement('div');
      row.className = 'issue-fixes';
      issue.fixes.forEach(fix => {
        const btn = document.createElement('button');
        btn.textContent = fix.label;
        btn.addEventListener('click', () => {
          addDiagLog(t('openedSettings') + ' (' + fix.action + ').');
          MicDiagnostics.openBrowserSetting(fix.action);
        });
        row.appendChild(btn);
      });
      card.appendChild(row);
    }
    diagBody.appendChild(card);
  }

  function renderResultBanner(text) {
    const banner = document.createElement('div');
    banner.className = 'result-banner';
    banner.textContent = text;
    diagBody.insertBefore(banner, diagBody.firstChild);
  }

  function renderDeviceSelector(devices) {
    const wrap = document.createElement('div');
    wrap.className = 'device-select-wrap';

    const label = document.createElement('label');
    label.textContent = currentLang === 'en' ? 'Microphone to use:' : 'Microfono a usar:';
    wrap.appendChild(label);

    const select = document.createElement('select');
    const optAuto = document.createElement('option');
    optAuto.value = '';
    optAuto.textContent = t('defaultMic');
    if (!settings.preferredMicDeviceId) optAuto.selected = true;
    select.appendChild(optAuto);

    devices.forEach((d, i) => {
      const opt = document.createElement('option');
      opt.value = d.deviceId;
      opt.textContent = d.label || ('Microfono ' + (i + 1));
      if (d.deviceId === settings.preferredMicDeviceId) opt.selected = true;
      select.appendChild(opt);
    });

    select.addEventListener('change', async () => {
      settings.preferredMicDeviceId = select.value;
      const chosen = devices.find(d => d.deviceId === select.value);
      settings.preferredMicLabel = chosen ? chosen.label : '';
      await saveSettings();
      addDiagLog(t('micChanged') + ': ' + (settings.preferredMicLabel || t('defaultMic')) + '.');
      runDiagnostics();
    });
    wrap.appendChild(select);

    const hint = document.createElement('div');
    hint.className = 'hint';
    hint.textContent = currentLang === 'en' ? 'If multiple microphones are connected, choosing the correct one here usually fixes the problem.' : 'Si hay varios microfonos conectados, elegir el correcto aqui suele resolver el problema.';
    wrap.appendChild(hint);

    diagBody.appendChild(wrap);
  }

  async function runDiagnostics() {
    renderLoading(t('analyzingMic'));
    const report = await MicDiagnostics.run(settings);
    lastReport = report;
    diagBody.innerHTML = '';

    const relevantIssues = report.issues.filter(i => !i.info);

    if (relevantIssues.length === 0) {
      const ok = document.createElement('div');
      ok.className = 'ok-banner';
      ok.textContent = t('noIssues');
      diagBody.appendChild(ok);
      addDiagLog(t('analysisComplete') + ': ' + t('noIssues'));
      btnFix.style.display = 'none';
    } else {
      report.issues.forEach(renderIssue);
      addDiagLog(t('analysisComplete') + ': ' + t('problemsDetected') + ' — ' + relevantIssues.map(i => i.title).join('; ') + '.');
      const hasFixableIssue = relevantIssues.some(i => i.fixes && i.fixes.length);
      btnFix.style.display = hasFixableIssue ? '' : 'none';
    }

    if (report.devices && report.devices.length > 0) {
      renderDeviceSelector(report.devices);
    }

    return relevantIssues.length;
  }

  async function attemptFix() {
    if (!lastReport) return;
    btnAnalyze.disabled = true;
    btnFix.disabled = true;
    renderLoading(t('applyingFix'));

    const relevantIssues = lastReport.issues.filter(i => !i.info);
    const openedActions = new Set();
    let resetPreferredDevice = false;

    for (const issue of relevantIssues) {
      if (issue.code === 'device-not-found' && settings.preferredMicDeviceId) {
        settings.preferredMicDeviceId = '';
        settings.preferredMicLabel = '';
        resetPreferredDevice = true;
        continue;
      }
      if (issue.fixes && issue.fixes.length) {
        for (const fix of issue.fixes) {
          if (fix.action && !openedActions.has(fix.action)) {
            MicDiagnostics.openBrowserSetting(fix.action);
            openedActions.add(fix.action);
          }
        }
      }
    }

    if (resetPreferredDevice) {
      await saveSettings();
      addDiagLog(t('defaultMicReset'));
    }
    openedActions.forEach(action => {
      addDiagLog(t('openedSettings') + ' (' + action + ') ' + t('checkManually'));
    });

    const remaining = await runDiagnostics();

    if (remaining === 0) {
      renderResultBanner(t('problemsFixed'));
      addDiagLog('Resultado: ' + t('problemsFixed'));
    } else {
      renderResultBanner(t('problemsNotFixed'));
      addDiagLog('Resultado: ' + t('problemsNotFixed') + ' (' + remaining + ' restante(s)).');
    }

    btnAnalyze.disabled = false;
    btnFix.disabled = false;
  }

  btnAnalyze.addEventListener('click', () => { addDiagLog(t('analysisRequested')); runDiagnostics(); });
  btnFix.addEventListener('click', () => { addDiagLog(t('fixRequested')); attemptFix(); });

  // ---------- inicializacion ----------
  (async () => {
    await loadSettings();
    applySettingsToUI();
    if (settings.saveConversation) restoreConversation();
    renderIntro();
    diagLogsEl.textContent = t('noLogYet');
    setStatus('disconnected');
  })();

}); // end DOMContentLoaded
