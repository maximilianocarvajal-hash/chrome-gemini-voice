'use strict';

// Al hacer click en el icono de la extension, se abre el panel lateral
chrome.sidePanel
  .setPanelBehavior({ openPanelOnActionClick: true })
  .catch((err) => console.error('[GVC] No se pudo configurar el side panel:', err));
